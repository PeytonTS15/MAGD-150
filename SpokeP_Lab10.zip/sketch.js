let player;

function setup() {
  createCanvas(600, 400);
  player = createSprite(300, 200, 50, 50);
}

function draw() {
  background(200);

  if (keyDown("LEFT_ARROW")) player.velocity.x = -5;
  else if (keyDown("RIGHT_ARROW")) player.velocity.x = 5;
  else player.velocity.x = 0;

  if (keyDown("UP_ARROW")) player.velocity.y = -5;
  else if (keyDown("DOWN_ARROW")) player.velocity.y = 5;
  else player.velocity.y = 0;

  drawSprites();
}